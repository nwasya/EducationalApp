from django.apps import AppConfig


class EduMarkConfig(AppConfig):
    name = 'Edu_Mark'
