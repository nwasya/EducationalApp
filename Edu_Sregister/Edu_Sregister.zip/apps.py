from django.apps import AppConfig


class EduSregisterConfig(AppConfig):
    name = 'Edu_Sregister'
