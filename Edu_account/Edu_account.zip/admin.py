from django.contrib import admin

# Register your models here.
from Edu_account.models import PassReset

admin.site.register(PassReset)