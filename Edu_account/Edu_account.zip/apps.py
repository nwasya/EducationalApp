from django.apps import AppConfig


class EduAccountConfig(AppConfig):
    name = 'Edu_account'
