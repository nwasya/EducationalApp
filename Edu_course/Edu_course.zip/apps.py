from django.apps import AppConfig


class EduBookConfig(AppConfig):
    name = 'Edu_course'
