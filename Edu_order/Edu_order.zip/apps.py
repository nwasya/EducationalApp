from django.apps import AppConfig


class EduOrderConfig(AppConfig):
    name = 'Edu_order'
